# simple-shortcuts
Simple Chrome extension that adds useful shortcuts.
